<?php

/**
 * Classe voiture 
 */
class Voiture {

    /** @var string $immatriculation Numéro d'immatriculation  */
    private $immatriculation;
    
    /** @var string $couleur Couleur  */
    private $couleur;
    
    /** @var int $poids Poids  */
    private $poids;
    
    /** @var int $puissance Puissance de la voiture  */
    private $puissance;
    
    /** @var float $capaciteReservoir Capacité du réservoir  */
    private $capaciteReservoir;
    
    /** @var float $niveauEssence Niveau de carburant . */
    private $niveauEssence;
    
    /** @var int $nombrePlaces Nombre de places  */
    private $nombrePlaces;
    
    /** @var bool $assure Statut d'assurance  */
    private $assure;
    
    /** @var string $messageTableauBord Message affiché sur le tableau de bord. */
    private $messageTableauBord;

    /**
     * Constructeur de la classe Voiture.
     * 
     *
     * @param string $immatriculation Numéro d'immatriculation
     * @param string $couleur Couleur.
     * @param int $poids Poids
     * @param int $puissance Puissance 
     * @param float $capaciteReservoir Capacité du réservoir 
     * @param int $nombrePlaces Nombre de places 
     */
    public function __construct($immatriculation, $couleur, $poids, $puissance, $capaciteReservoir, $nombrePlaces) {
        $this->immatriculation = $immatriculation;
        $this->couleur = $couleur;
        $this->poids = $poids;
        $this->puissance = $puissance;
        $this->capaciteReservoir = $capaciteReservoir;
        $this->nombrePlaces = $nombrePlaces;
        
        // Initialisation des autres attributs
        $this->niveauEssence = 5.0; // Réservoir livré avec 5 litres de carburant
        $this->assure = false; // La voiture n'est pas assurée à la livraison
        $this->messageTableauBord = "Bienvenue dans votre nouvelle voiture !"; // Message d'accueil
    }

    /**
     * Getter pour l'immatriculation.
     *
     * @return string
     */
    public function getImmatriculation() {
        return $this->immatriculation;
    }

    /**
     * Getter pour la couleur.
     *
     * @return string
     */
    public function getCouleur() {
        return $this->couleur;
    }

    /**
     * Getter pour le poids.
     *
     * @return int
     */
    public function getPoids() {
        return $this->poids;
    }

    /**
     * Getter pour la puissance.
     *
     * @return int
     */
    public function getPuissance() {
        return $this->puissance;
    }

    /**
     * Getter pour la capacité du réservoir.
     *
     * @return float
     */
    public function getCapaciteReservoir() {
        return $this->capaciteReservoir;
    }

    /**
     * Getter pour le niveau d'essence.
     *
     * @return float
     */
    public function getNiveauEssence() {
        return $this->niveauEssence;
    }

    /**
     * Getter pour le nombre de places.
     *
     * @return int
     */
    public function getNombrePlaces() {
        return $this->nombrePlaces;
    }

    /**
     * Getter pour le statut d'assurance.
     *
     * @return bool
     */
    public function getAssure() {
        return $this->assure;
    }

    /**
     * Getter 
     *
     * @return string
     */
    public function getMessageTableauBord() {
        return $this->messageTableauBord;
    }

    /**
     * Setter 
     *
     * @param bool $assure Nouveau statut d'assurance.
     */
    public function setAssure($assure) {
        $this->assure = $assure;
        $this->messageTableauBord = "Statut d'assurance mis à jour.";
    }

    /**
     * 
     *
     * @param string $nouvelleCouleur Nouvelle couleur
     */
    public function repeindre($nouvelleCouleur) {
        if ($nouvelleCouleur === $this->couleur) {
            $this->messageTableauBord = "Merci pour ce rafraîchissement de couleur !";
        } else {
            $this->couleur = $nouvelleCouleur;
            $this->messageTableauBord = "Merci pour ce changement de couleur !";
        }
    }

    /**
     * 
     *
     * @param float $quantite Quantité de carburant à ajouter.
     * @return string
     */
    public function mettreEssence($quantite) {
        if ($quantite <= 0) {
            return "La quantité doit être positive.";
        }

        $nouveauNiveau = $this->niveauEssence + $quantite;
        if ($nouveauNiveau > $this->capaciteReservoir) {
            return "Le réservoir ne peut pas contenir autant de carburant.";
        }
        $this->niveauEssence = $nouveauNiveau;
        return "Ajout de carburant effectué avec succès.";
    }

    /**
     * 
     *
     * @param float $distance Distance à parcourir en km.
     * @param float $vitesseMoyenne Vitesse moyenne du déplacement en km/h.
     * @return string
     */
    public function seDeplacer($distance, $vitesseMoyenne) {
        // Calcul de la consommation de carburant
        $consommation = 0;
        if ($vitesseMoyenne < 50) {
            $consommation = 15 * $distance / 100;
        } elseif ($vitesseMoyenne >= 70 && $vitesseMoyenne < 90) {
            $consommation = 5 * $distance / 100;
        } elseif ($vitesseMoyenne >= 95 && $vitesseMoyenne < 130) {
            $consommation = 8 * $distance / 100;
        } else {
            $consommation = 12 * $distance / 100;
        }

        // Vérification le carburant 
        if ($consommation > $this->niveauEssence) {
            return "Déplacement impossible. Niveau de carburant insuffisant.";
        }

        // consommation du carburant
        $this->niveauEssence -= $consommation;
        return "Déplacement effectué avec succès. Consommation : " . $consommation . " litres.";
    }

    /**
     *  afficher les informations de la voiture.
     *
     * @return string
     */
    public function __toString() {
        return "Voiture immatriculée " . $this->immatriculation . ", puissance " . $this->puissance . " chevaux, de couleur " . $this->couleur . ".";
    }
}

//  la classe Voiture
$maVoiture = new Voiture("121585afd", "rouge", 1200, 90, 50, 5);
$maVoiture->setAssure(true); // Assurer la voiture

//  informations de la voiture
echo $maVoiture . "<br>";

// Test de la méthode Repeindre
$maVoiture->repeindre("gris,vert,blanc,noir");
echo $maVoiture->getMessageTableauBord() . "<br>";

// Test de la méthode Mettre_essence
echo $maVoiture->mettreEssence(10) . "<br>";

// statut d'assurance
echo "La voiture est " . ($maVoiture->getAssure() ? "assurée" : "non assurée");